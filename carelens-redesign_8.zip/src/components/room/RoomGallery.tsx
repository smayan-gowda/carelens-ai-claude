import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { X, Image as ImageIcon } from "lucide-react";
import { format } from "date-fns";
import type { ScanResult } from "@/types/ai";
import type { RoomImage } from "@/types/home";

interface RoomGalleryProps {
  roomImages: RoomImage[];
  roomScans: ScanResult[];
}

/** A simple drag-to-reveal comparison between the earliest and latest scan
 * photo — real photos of the real room, not an illustration. */
function BeforeAfterSlider({ before, after }: { before: { url: string; date: string }; after: { url: string; date: string } }) {
  const [pos, setPos] = useState(50);

  return (
    <div className="relative aspect-[16/10] w-full overflow-hidden bg-neutral-900 select-none">
      <img src={after.url} className="absolute inset-0 w-full h-full object-cover" alt="Most recent" draggable={false} />
      <div className="absolute inset-0 overflow-hidden" style={{ clipPath: `inset(0 ${100 - pos}% 0 0)` }}>
        <img src={before.url} className="absolute inset-0 w-full h-full object-cover" alt="Earliest" draggable={false} />
      </div>

      <div className="absolute top-0 bottom-0 w-px bg-white/80" style={{ left: `${pos}%` }}>
        <div className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-8 h-8 rounded-full bg-white shadow-lg flex items-center justify-center">
          <div className="w-3 h-3 border-r border-l border-neutral-400" />
        </div>
      </div>

      <input
        type="range"
        min={0}
        max={100}
        value={pos}
        onChange={(e) => setPos(Number(e.target.value))}
        className="absolute inset-0 w-full h-full opacity-0 cursor-ew-resize"
        aria-label="Compare before and after"
      />

      <span className="absolute bottom-4 left-4 tabular text-[10px] text-white bg-black/60 px-2 py-1 pointer-events-none">
        {format(new Date(before.date), "MMM yyyy")}
      </span>
      <span className="absolute bottom-4 right-4 tabular text-[10px] text-white bg-black/60 px-2 py-1 pointer-events-none">
        {format(new Date(after.date), "MMM yyyy")}
      </span>
    </div>
  );
}

export function RoomGallery({ roomImages, roomScans }: RoomGalleryProps) {
  const [selected, setSelected] = useState<string | null>(null);

  const completedScans = [...roomScans]
    .filter((s) => s.status === "Completed" && (s.images?.[0] || (s as any).originalImage))
    .sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());

  const scanPhotos = completedScans.map((s) => ({
    url: s.images?.[0] || (s as any).originalImage,
    date: s.createdAt,
    id: s.id,
  }));

  const allPhotos = [
    ...roomImages.map((img) => ({ url: img.url, date: img.uploadedAt, id: img.id })),
    ...scanPhotos,
  ].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  const canCompare = scanPhotos.length >= 2;

  return (
    <div id="gallery" className="scroll-mt-24">
      <span className="field-tag text-muted-foreground block mb-3">Gallery</span>

      {canCompare && (
        <div className="mb-10">
          <p className="text-sm text-muted-foreground mb-4">Drag to compare the earliest and most recent assessment.</p>
          <BeforeAfterSlider before={scanPhotos[0]} after={scanPhotos[scanPhotos.length - 1]} />
        </div>
      )}

      {allPhotos.length > 0 ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-px bg-border border border-border">
          {allPhotos.map((photo, i) => (
            <motion.button
              key={`${photo.id}-${i}`}
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true, margin: "-40px" }}
              transition={{ delay: Math.min(i, 8) * 0.04 }}
              onClick={() => setSelected(photo.url)}
              className="group aspect-square overflow-hidden relative bg-muted text-left"
            >
              <img src={photo.url} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" alt="" />
              <div className="absolute inset-0 bg-black/0 group-hover:bg-black/15 transition-colors" />
              <span className="absolute bottom-2 left-2 tabular text-[9px] text-white bg-black/60 px-1.5 py-0.5 opacity-0 group-hover:opacity-100 transition-opacity">
                {format(new Date(photo.date), "MMM d, yyyy")}
              </span>
            </motion.button>
          ))}
        </div>
      ) : (
        <div className="border-t border-b border-border py-14 text-center">
          <ImageIcon className="w-5 h-5 text-muted-foreground/40 mx-auto mb-3" strokeWidth={1.5} />
          <p className="text-sm text-muted-foreground">No photos yet</p>
        </div>
      )}

      <AnimatePresence>
        {selected && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/90 backdrop-blur-sm flex items-center justify-center p-4"
            onClick={() => setSelected(null)}
          >
            <button
              className="absolute top-6 right-6 text-white hover:bg-white/10 w-10 h-10 flex items-center justify-center"
              onClick={() => setSelected(null)}
            >
              <X className="w-5 h-5" />
            </button>
            <motion.img
              initial={{ scale: 0.95 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.95 }}
              src={selected}
              className="max-w-full max-h-[90vh] object-contain"
              onClick={(e) => e.stopPropagation()}
            />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
