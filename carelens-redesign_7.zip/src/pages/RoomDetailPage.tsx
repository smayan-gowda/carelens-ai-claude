import { useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useHomeStore } from "@/stores/useHomeStore";
import { useScanStore } from "@/stores/scanStore";
import { Button } from "@/components/ui/button";
import {
  ArrowLeft,
  Image as ImageIcon,
  MoreVertical,
  X,
  Trash2,
  Camera,
  ArrowUpRight
} from "lucide-react";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { format } from "date-fns";
import { toast } from "sonner";
import { motion, AnimatePresence } from "motion/react";

export function RoomDetailPage() {
  const { homeId, roomId } = useParams();
  const navigate = useNavigate();
  const { homes, deleteRoom } = useHomeStore();
  const { getScansForRoom } = useScanStore();

  const [showDeleteRoomConfirm, setShowDeleteRoomConfirm] = useState(false);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);

  const home = homes.find(h => h.id === homeId);
  const room = home?.rooms.find(r => r.id === roomId);
  const roomScans = getScansForRoom(roomId || '').sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  if (!home || !room) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] text-center">
        <h2 className="text-2xl font-semibold mb-2">Zone not found</h2>
        <p className="text-muted-foreground mb-6">This zone doesn't exist or has been removed.</p>
        <Button onClick={() => navigate(`/properties/${homeId}`)}>Return to Property</Button>
      </div>
    );
  }

  const handleDeleteRoom = () => {
    deleteRoom(home.id, room.id);
    toast.success("Zone removed");
    navigate(`/properties/${home.id}`);
  };

  return (
    <div className="space-y-10">
      {/* Lightbox */}
      <AnimatePresence>
        {selectedImage && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/90 backdrop-blur-sm flex items-center justify-center p-4"
          >
            <button
              className="absolute top-6 right-6 text-white hover:bg-white/10 w-10 h-10 flex items-center justify-center"
              onClick={() => setSelectedImage(null)}
            >
              <X className="w-5 h-5" />
            </button>
            <motion.img
              initial={{ scale: 0.95 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.95 }}
              src={selectedImage}
              className="max-w-full max-h-[90vh] object-contain"
            />
          </motion.div>
        )}
      </AnimatePresence>

      {/* Back & Actions */}
      <div className="flex items-center justify-between">
        <Button variant="ghost" onClick={() => navigate(`/properties/${home.id}`)}>
          <ArrowLeft className="w-4 h-4 mr-2" /> {home.name}
        </Button>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon">
              <MoreVertical className="w-5 h-5" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem className="text-destructive" onClick={() => setShowDeleteRoomConfirm(true)}>
              <Trash2 className="w-4 h-4 mr-2" /> Remove Zone
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      {showDeleteRoomConfirm && (
        <motion.div
          initial={{ opacity: 0, scale: 0.97 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-destructive/10 border border-destructive/20 p-6 flex items-center justify-between"
        >
          <div>
            <h3 className="text-destructive font-medium">Remove this zone?</h3>
            <p className="text-destructive/80 text-sm mt-1">This action cannot be undone.</p>
          </div>
          <div className="flex gap-3">
            <Button variant="ghost" onClick={() => setShowDeleteRoomConfirm(false)}>Cancel</Button>
            <Button variant="destructive" onClick={handleDeleteRoom}>Confirm Delete</Button>
          </div>
        </motion.div>
      )}

      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 pb-6 border-b border-border">
        <div>
          <span className="field-tag text-muted-foreground block mb-2 capitalize">{room.type} · Added {format(room.createdAt, 'MMM yyyy')}</span>
          <h1 className="text-4xl md:text-5xl font-semibold tracking-tight">{room.name}</h1>
        </div>
        <Button variant="brand" size="lg" onClick={() => navigate(`/properties/${home.id}/rooms/${room.id}/scan`)}>
          <Camera className="w-4 h-4 mr-2" /> New Assessment
        </Button>
      </div>

      <div className="grid md:grid-cols-3 gap-12">
        {/* Left Col: Scans & History */}
        <div className="md:col-span-2">
          <span className="field-tag text-muted-foreground block mb-6">Assessment History</span>

          {roomScans.length === 0 ? (
            <div className="border-t border-b border-border py-16 text-center">
              <Camera className="w-6 h-6 text-muted-foreground/40 mx-auto mb-4" strokeWidth={1.5} />
              <h3 className="font-medium text-lg mb-2">No assessments yet</h3>
              <p className="text-muted-foreground text-sm mb-6 max-w-xs mx-auto">Run a technical scan to identify environmental hazards.</p>
            </div>
          ) : (
            <div className="border-t border-border">
              {roomScans.map((scan, idx) => (
                <motion.div
                  key={scan.id}
                  initial={{ opacity: 0 }}
                  whileInView={{ opacity: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: idx * 0.05 }}
                  onClick={() => navigate(`/properties/${home.id}/rooms/${room.id}/assessments/${scan.id}`)}
                  className="group cursor-pointer flex gap-5 py-5 border-b border-border"
                >
                  <div className="w-28 h-28 bg-muted overflow-hidden shrink-0 relative brackets text-foreground/20">
                    <div className="bracket-tl" /><div className="bracket-br" />
                    {scan.images?.[0] || (scan as any).originalImage ? (
                      <img src={scan.images?.[0] || (scan as any).originalImage} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center">
                        <ImageIcon className="w-6 h-6 text-muted-foreground/30" strokeWidth={1.5} />
                      </div>
                    )}
                  </div>
                  <div className="flex-1 py-1 flex flex-col justify-between min-w-0">
                    <div>
                      <div className="flex justify-between items-start gap-3">
                        <h3 className="font-medium text-base tracking-tight">Environmental Audit</h3>
                        <ArrowUpRight className="w-4 h-4 text-muted-foreground/40 group-hover:text-foreground transition-colors shrink-0" />
                      </div>
                      <p className="text-sm text-muted-foreground mt-1">{format(scan.createdAt, 'MMMM d, yyyy')}</p>
                    </div>
                    <div className="flex items-center gap-4">
                      <span className="tabular text-sm font-medium">{scan.hazards.length} findings</span>
                      {scan.hazards.filter(h => h.severity === 'High' || h.severity === 'Critical').length > 0 && (
                        <span className="field-tag text-destructive">Critical</span>
                      )}
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          )}
        </div>

        {/* Right Col: Gallery */}
        <div>
          <span className="field-tag text-muted-foreground block mb-6">Gallery</span>

          <div className="grid grid-cols-2 gap-px bg-border border border-border">
            {room.images?.length > 0 ? (
              room.images.map((img) => (
                <div
                  key={img.id}
                  className="aspect-square overflow-hidden cursor-pointer relative group bg-muted"
                  onClick={() => setSelectedImage(img.url)}
                >
                  <img src={img.url} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" />
                  <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors duration-300" />
                </div>
              ))
            ) : (
              <div className="col-span-2 bg-card p-8 text-center">
                <ImageIcon className="w-6 h-6 text-muted-foreground/40 mx-auto mb-2" strokeWidth={1.5} />
                <p className="text-sm text-muted-foreground">No reference photos</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
