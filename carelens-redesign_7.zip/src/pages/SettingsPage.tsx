import { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { useHomeStore } from "@/stores/useHomeStore";
import { useAuthStore } from "@/stores/useAuthStore";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
} from "@/components/ui/select";
import {
  User,
  Home,
  Bell,
  Shield,
  LogOut,
  Trash2,
  Save,
  Camera,
  Mail,
  UserCircle,
  Plus,
  ArrowUpRight
} from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { toast } from "sonner";
import { motion } from 'motion/react';

// Shared field wrapper for the whole page — a labeled row against a hairline,
// not a rounded bordered box. This is the one row primitive every setting
// (toggle, select, button) reuses so the page reads as a single ledger.
function FieldRow({ label, description, children }: { label: string; description?: string; children: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-6 py-5 border-b border-border last:border-b-0">
      <div className="min-w-0">
        <p className="text-sm font-medium tracking-tight">{label}</p>
        {description && <p className="text-xs text-muted-foreground mt-1 max-w-sm">{description}</p>}
      </div>
      <div className="shrink-0">{children}</div>
    </div>
  );
}

function SectionPanel({ title, description, children, footer }: { title: string; description?: string; children: React.ReactNode; footer?: React.ReactNode }) {
  return (
    <div className="border border-border bg-card">
      <div className="px-6 py-5 border-b border-border">
        <span className="field-tag text-muted-foreground block mb-1.5">{title}</span>
        {description && <p className="text-sm text-muted-foreground">{description}</p>}
      </div>
      <div className="px-6">{children}</div>
      {footer && <div className="px-6 py-4 border-t border-border bg-muted/20">{footer}</div>}
    </div>
  );
}

export function SettingsPage() {
  const navigate = useNavigate();
  const { profile, user, logout, updateProfile } = useAuthStore();
  const { homes } = useHomeStore();
  const [activeTab, setActiveTab] = useState('profile');
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [formData, setFormData] = useState({
    name: profile?.name || user?.displayName || '',
    email: profile?.email || user?.email || '',
    role: profile?.role || 'Caregiver',
    ageGroup: profile?.ageGroup || '65-74',
    notificationsEnabled: profile?.notificationsEnabled ?? true,
    privacyLevel: profile?.privacyLevel || 'Private',
    avatar: profile?.avatar || user?.photoURL || '',
  });

  const getRoleLabel = (val: string) => {
    switch (val) {
      case "Homeowner": return "Homeowner";
      case "Caregiver": return "Caregiver";
      case "Family member": return "Family Member";
      default: return val || "";
    }
  };

  const getAgeGroupLabel = (val: string) => {
    switch (val) {
      case "65-74": return "65-74 years";
      case "75-84": return "75-84 years";
      case "85+": return "85+ years";
      default: return val || "";
    }
  };

  const [switches, setSwitches] = useState({
    autoDetectRooms: true,
    saveOriginalPhotos: true,
    emailSummaries: true,
    newScanReports: true,
    communityMentions: true,
    hazardAlerts: true,
    accountActivity: true,
    shareAnonymizedData: true,
  });

  useEffect(() => {
    if (profile || user) {
      setFormData({
        name: profile?.name || user?.displayName || '',
        email: profile?.email || user?.email || '',
        role: profile?.role || 'Caregiver',
        ageGroup: profile?.ageGroup || '65-74',
        notificationsEnabled: profile?.notificationsEnabled ?? true,
        privacyLevel: profile?.privacyLevel || 'Private',
        avatar: profile?.avatar || user?.photoURL || '',
      });
    }
  }, [profile, user]);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => setFormData(prev => ({ ...prev, avatar: reader.result as string }));
      reader.readAsDataURL(file);
    }
  };

  const handleRemoveImage = () => setFormData(prev => ({ ...prev, avatar: '' }));

  const handleSave = async () => {
    try {
      await updateProfile(formData);
      toast.success("Settings updated successfully");
    } catch (err) {
      console.error(err);
      toast.error("Failed to update settings");
    }
  };

  const handleSignOut = async () => {
    await logout();
    toast.success("Signed out successfully");
  };

  const navItems = [
    { id: 'profile', label: 'Profile', icon: User },
    { id: 'homes', label: 'Homes & Rooms', icon: Home },
    { id: 'notifications', label: 'Notifications', icon: Bell },
    { id: 'privacy', label: 'Privacy & Security', icon: Shield },
  ];

  return (
    <div className="space-y-10">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 pb-6 border-b border-border">
        <div>
          <span className="field-tag text-muted-foreground block mb-2">Account</span>
          <h1 className="text-4xl md:text-5xl font-semibold tracking-tight">Settings</h1>
        </div>
        <div className="flex items-center gap-2 field-tag text-muted-foreground border border-border px-3 py-2">
          <span className="h-1.5 w-1.5 bg-success animate-pulse" />
          System Status: Optimal
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-12 gap-10">
        <aside className="md:col-span-3">
          <nav className="border-t border-border">
            {navItems.map((item) => (
              <button
                key={item.id}
                className={`w-full flex items-center gap-3 py-3.5 border-b border-border text-left transition-colors ${activeTab === item.id ? 'text-brand' : 'text-muted-foreground hover:text-foreground'}`}
                onClick={() => setActiveTab(item.id)}
              >
                <item.icon className="h-4 w-4 shrink-0" strokeWidth={1.75} />
                <span className="text-sm font-medium">{item.label}</span>
              </button>
            ))}
          </nav>

          <div className="mt-8">
            <span className="field-tag text-destructive block mb-3">Danger Zone</span>
            <div className="border border-destructive/20">
              <button onClick={handleSignOut} className="w-full flex items-center gap-3 px-4 py-3 text-sm text-destructive hover:bg-destructive/5 transition-colors border-b border-destructive/20">
                <LogOut className="h-4 w-4" /> Sign Out
              </button>
              <button onClick={() => toast.success("Account deletion request submitted")} className="w-full flex items-center gap-3 px-4 py-3 text-sm text-destructive hover:bg-destructive/5 transition-colors">
                <Trash2 className="h-4 w-4" /> Delete Account
              </button>
            </div>
          </div>
        </aside>

        <div className="md:col-span-9 space-y-8">
          {activeTab === 'profile' && (
            <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="space-y-8">
              <SectionPanel
                title="Public Profile"
                description="Your identity within the CareLens community."
                footer={
                  <div className="flex justify-between items-center">
                    <p className="field-tag text-muted-foreground">Saved locally</p>
                    <Button variant="brand" onClick={handleSave}><Save className="h-4 w-4 mr-2" /> Save Changes</Button>
                  </div>
                }
              >
                <div className="flex flex-col sm:flex-row items-center gap-8 py-8 border-b border-border">
                  <div className="relative group">
                    <Avatar className="h-24 w-24 rounded-md border border-border">
                      <AvatarImage src={formData.avatar || undefined} />
                      <AvatarFallback className="rounded-md text-2xl font-semibold bg-muted">{formData.name ? formData.name[0] : 'U'}</AvatarFallback>
                    </Avatar>
                    <button onClick={() => fileInputRef.current?.click()} className="absolute -bottom-1.5 -right-1.5 h-8 w-8 rounded-sm bg-foreground text-background flex items-center justify-center">
                      <Camera className="h-3.5 w-3.5" />
                    </button>
                    <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handleImageUpload} />
                  </div>
                  <div className="space-y-2 text-center sm:text-left">
                    <h3 className="text-lg font-semibold tracking-tight">Profile Picture</h3>
                    <p className="text-sm text-muted-foreground max-w-[300px]">Visible to other caregivers when you post in the community.</p>
                    <div className="flex gap-2 justify-center sm:justify-start pt-2">
                      <Button variant="outline" size="sm" onClick={() => fileInputRef.current?.click()}>Upload New</Button>
                      <Button variant="ghost" size="sm" className="text-destructive hover:text-destructive" onClick={handleRemoveImage}>Remove</Button>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 py-8">
                  <div className="space-y-2">
                    <Label className="field-tag text-muted-foreground">Full Name</Label>
                    <div className="relative">
                      <UserCircle className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground/60" />
                      <Input value={formData.name} onChange={(e) => setFormData({ ...formData, name: e.target.value })} className="pl-10 h-11" />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label className="field-tag text-muted-foreground">Email Address</Label>
                    <div className="relative">
                      <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground/60" />
                      <Input type="email" value={formData.email} onChange={(e) => setFormData({ ...formData, email: e.target.value })} className="pl-10 h-11" />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label className="field-tag text-muted-foreground">Primary Role</Label>
                    <Select value={formData.role} onValueChange={(val: any) => setFormData({ ...formData, role: val })}>
                      <SelectTrigger className="h-11 w-full">
                        <span className="flex flex-1 text-left truncate">{getRoleLabel(formData.role) || "Select role"}</span>
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Homeowner">Homeowner</SelectItem>
                        <SelectItem value="Caregiver">Caregiver</SelectItem>
                        <SelectItem value="Family member">Family Member</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label className="field-tag text-muted-foreground">Resident Age Group</Label>
                    <Select value={formData.ageGroup} onValueChange={(val: any) => setFormData({ ...formData, ageGroup: val })}>
                      <SelectTrigger className="h-11 w-full">
                        <span className="flex flex-1 text-left truncate">{getAgeGroupLabel(formData.ageGroup) || "Select age group"}</span>
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="65-74">65-74 years</SelectItem>
                        <SelectItem value="75-84">75-84 years</SelectItem>
                        <SelectItem value="85+">85+ years</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </SectionPanel>
            </motion.div>
          )}

          {activeTab === 'homes' && (
            <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="space-y-8">
              <SectionPanel title="Manage Homes" description="Configure your monitored properties.">
                <div className="flex justify-end pt-5">
                  <Button variant="outline" size="sm" onClick={() => navigate('/properties/new')}><Plus className="mr-2 h-4 w-4" /> Add Home</Button>
                </div>
                <div className="pb-5">
                  {homes.map((home) => (
                    <div key={home.id} onClick={() => navigate(`/properties/${home.id}`)} className="flex items-center justify-between py-4 border-t border-border group cursor-pointer">
                      <div className="flex items-center gap-4">
                        <div className="h-11 w-11 rounded-sm border border-border flex items-center justify-center">
                          <Home className="h-4 w-4" strokeWidth={1.6} />
                        </div>
                        <div>
                          <h4 className="font-medium text-sm tracking-tight">{home.name}</h4>
                          <p className="text-xs text-muted-foreground">{home.address}</p>
                        </div>
                      </div>
                      <ArrowUpRight className="h-4 w-4 text-muted-foreground/40 group-hover:text-foreground transition-colors" />
                    </div>
                  ))}
                </div>
              </SectionPanel>

              <SectionPanel title="Room Settings" description="Default configurations for your safety scans.">
                <FieldRow label="Auto-detect Rooms" description="Automatically identify room types during scans.">
                  <Switch checked={switches.autoDetectRooms} onCheckedChange={(val) => setSwitches({ ...switches, autoDetectRooms: val })} />
                </FieldRow>
                <FieldRow label="Save Original Photos" description="Keep unannotated copies of all scan images.">
                  <Switch checked={switches.saveOriginalPhotos} onCheckedChange={(val) => setSwitches({ ...switches, saveOriginalPhotos: val })} />
                </FieldRow>
              </SectionPanel>
            </motion.div>
          )}

          {activeTab === 'notifications' && (
            <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="space-y-8">
              <SectionPanel title="Alert Preferences" description="Choose how and when you want to be notified.">
                <span className="field-tag text-muted-foreground/70 block pt-5">Channels</span>
                <FieldRow label="Push Notifications" description="Receive real-time alerts on your device.">
                  <Switch checked={formData.notificationsEnabled} onCheckedChange={(val) => setFormData({ ...formData, notificationsEnabled: val })} />
                </FieldRow>
                <FieldRow label="Email Summaries" description="Weekly safety and activity reports.">
                  <Switch checked={switches.emailSummaries} onCheckedChange={(val) => setSwitches({ ...switches, emailSummaries: val })} />
                </FieldRow>

                <span className="field-tag text-muted-foreground/70 block pt-8">Event Types</span>
                <FieldRow label="New Scan Reports"><Switch checked={switches.newScanReports} onCheckedChange={(val) => setSwitches({ ...switches, newScanReports: val })} /></FieldRow>
                <FieldRow label="Community Mentions"><Switch checked={switches.communityMentions} onCheckedChange={(val) => setSwitches({ ...switches, communityMentions: val })} /></FieldRow>
                <FieldRow label="Hazard Alerts"><Switch checked={switches.hazardAlerts} onCheckedChange={(val) => setSwitches({ ...switches, hazardAlerts: val })} /></FieldRow>
                <FieldRow label="Account Activity"><Switch checked={switches.accountActivity} onCheckedChange={(val) => setSwitches({ ...switches, accountActivity: val })} /></FieldRow>
              </SectionPanel>
            </motion.div>
          )}

          {activeTab === 'privacy' && (
            <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="space-y-8">
              <SectionPanel title="Security" description="Protect your account and safety data.">
                <FieldRow label="Two-Factor Authentication" description="Add an extra layer of security to your account.">
                  <Button variant="outline" size="sm" onClick={() => toast.success("Two-Factor Authentication setup email sent")}>Enable</Button>
                </FieldRow>
                <FieldRow label="Account Password" description="Update your password regularly for better security.">
                  <Button variant="outline" size="sm" onClick={() => toast.success("Password reset email sent")}>Change</Button>
                </FieldRow>
              </SectionPanel>

              <SectionPanel title="Data Privacy" description="Control how your data is used and shared.">
                <FieldRow label="Profile Visibility" description="Control who can see your profile in the community.">
                  <Select value={formData.privacyLevel} onValueChange={(val: any) => setFormData({ ...formData, privacyLevel: val })}>
                    <SelectTrigger className="w-36 h-10"><span>{formData.privacyLevel}</span></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Private">Private</SelectItem>
                      <SelectItem value="Limited">Limited</SelectItem>
                      <SelectItem value="Public">Public</SelectItem>
                    </SelectContent>
                  </Select>
                </FieldRow>
                <FieldRow label="Share Anonymized Data" description="Help improve our AI by sharing anonymous scan data.">
                  <Switch checked={switches.shareAnonymizedData} onCheckedChange={(val) => setSwitches({ ...switches, shareAnonymizedData: val })} />
                </FieldRow>
              </SectionPanel>
            </motion.div>
          )}
        </div>
      </div>
    </div>
  );
}
