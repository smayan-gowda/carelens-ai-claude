import { Button } from '@/components/ui/button';
import { ZoomIn, Eye } from 'lucide-react';
import { motion } from 'motion/react';
import { Hazard, DetectedObject } from '@/types/ai';
import { useState } from 'react';

interface InteractiveImageProps {
  image?: string;
  hazards: Hazard[];
  detectedObjects?: DetectedObject[];
  selectedHazardId: string | null;
  onSelectHazard: (id: string | null) => void;
}

export function InteractiveImage({ image, hazards, detectedObjects, selectedHazardId, onSelectHazard }: InteractiveImageProps) {
  const [isZoomed, setIsZoomed] = useState(false);

  return (
    <div className="border border-border bg-card overflow-hidden">
      <div className="px-5 py-3.5 border-b border-border flex items-center justify-between">
        <span className="field-tag text-muted-foreground">Interactive Scan</span>
        <button onClick={() => setIsZoomed(!isZoomed)} className="text-muted-foreground hover:text-foreground p-1">
          <ZoomIn className="h-4 w-4" />
        </button>
      </div>
      <div className="relative bg-neutral-950">
        {image ? (
          <div className={`relative overflow-hidden ${isZoomed ? 'cursor-move' : ''}`}>
            <motion.div
              className="relative origin-center"
              animate={isZoomed ? { scale: 1.5 } : { scale: 1 }}
              drag={isZoomed}
              dragConstraints={isZoomed ? { left: -200, right: 200, top: -200, bottom: 200 } : { left: 0, right: 0, top: 0, bottom: 0 }}
              dragElastic={0.1}
            >
              <img src={image} alt="Room scan" className="w-full h-auto block opacity-85 pointer-events-none" />

              {detectedObjects?.map((obj, i) => {
                if (!obj.boundingBox) return null;
                let box = { ...obj.boundingBox };
                if (box.x <= 1 && box.y <= 1 && box.width <= 1 && box.height <= 1 && box.width > 0) {
                  box = { x: box.x * 100, y: box.y * 100, width: box.width * 100, height: box.height * 100 };
                } else if (box.x > 100 || box.y > 100 || box.width > 100 || box.height > 100) {
                  box = { x: box.x / 10, y: box.y / 10, width: box.width / 10, height: box.height / 10 };
                }
                return (
                  <div
                    key={i}
                    className="absolute border border-white/25 pointer-events-none"
                    style={{ left: `${box.x}%`, top: `${box.y}%`, width: `${box.width}%`, height: `${box.height}%` }}
                  >
                    <span className="absolute -top-5 left-0 tabular text-[9px] text-white/70 bg-black/60 px-1.5 py-0.5 whitespace-nowrap">
                      {obj.name}
                    </span>
                  </div>
                );
              })}

              {hazards.map((hazard, index) => {
                let box = hazard.boundingBox ? { ...hazard.boundingBox } : { x: 20 + index * 10, y: 20 + index * 10, width: 15, height: 15 };
                if (box.x <= 1 && box.y <= 1 && box.width <= 1 && box.height <= 1 && box.width > 0) {
                  box = { x: box.x * 100, y: box.y * 100, width: box.width * 100, height: box.height * 100 };
                } else if (box.x > 100 || box.y > 100 || box.width > 100 || box.height > 100) {
                  box = { x: box.x / 10, y: box.y / 10, width: box.width / 10, height: box.height / 10 };
                }
                const isSelected = selectedHazardId === hazard.id;
                return (
                  <div
                    key={hazard.id}
                    className={`absolute border-2 transition-colors cursor-pointer group brackets ${isSelected ? 'border-brand bg-brand/15 z-20 text-brand' : 'border-destructive bg-destructive/15 z-10 hover:bg-destructive/25 text-destructive'}`}
                    style={{ left: `${box.x}%`, top: `${box.y}%`, width: `${box.width}%`, height: `${box.height}%` }}
                    onClick={() => onSelectHazard(isSelected ? null : hazard.id)}
                  >
                    <div className="bracket-tl" /><div className="bracket-br" />
                    <span className={`absolute -top-3 -right-3 w-5 h-5 flex items-center justify-center text-white text-[10px] font-bold transition-transform ${isSelected ? 'bg-brand scale-110' : 'bg-destructive group-hover:scale-110'}`}>
                      {String(index + 1).padStart(2, "0")}
                    </span>
                  </div>
                );
              })}
            </motion.div>
          </div>
        ) : (
          <div className="p-12 text-center">
            <Eye className="h-6 w-6 mx-auto text-white/30 mb-2" strokeWidth={1.5} />
            <p className="text-sm text-white/50">No image available</p>
          </div>
        )}
      </div>
      <div className="px-5 py-3 border-t border-border flex items-center justify-between text-xs text-muted-foreground">
        <span className="tabular">{detectedObjects?.length || 0} objects detected</span>
        <span className="tabular">{hazards.length} hazards found</span>
      </div>
    </div>
  );
}
