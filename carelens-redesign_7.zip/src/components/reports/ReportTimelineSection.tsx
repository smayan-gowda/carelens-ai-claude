import { motion } from "motion/react";
import { Link } from "react-router-dom";
import type { ScanResult } from "@/types/ai";
import { projectedScore } from "./reportMath";

interface ReportTimelineSectionProps {
  currentScan: ScanResult;
  roomScans: ScanResult[];
  homeId: string;
  roomId: string;
}

const scoreColor = (score: number) => (score >= 85 ? "text-success" : score >= 60 ? "text-warning" : "text-destructive");
const dotColor = (score: number) => (score >= 85 ? "bg-success" : score >= 60 ? "bg-warning" : "bg-destructive");

export function ReportTimelineSection({ currentScan, roomScans, homeId, roomId }: ReportTimelineSectionProps) {
  const history = roomScans
    .filter((s) => s.status === "Completed")
    .sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());

  const potential = projectedScore(currentScan.safetyScore, currentScan.recommendations);
  const scores = [...history.map((s) => s.safetyScore), potential];
  const min = Math.min(...scores, 0);
  const max = Math.max(...scores, 100);
  const range = Math.max(1, max - min);

  const points = history.map((s) => ({
    id: s.id,
    date: s.createdAt,
    score: s.safetyScore,
    isCurrent: s.id === currentScan.id,
  }));

  return (
    <div id="timeline" className="scroll-mt-24">
      <span className="field-tag text-muted-foreground block mb-3">Timeline</span>
      <p className="text-muted-foreground mb-10 max-w-lg">
        {history.length > 1
          ? "How this room's safety score has changed across every assessment."
          : "This is the first assessment on record for this room — future scans will build a history here."}
      </p>

      {points.length > 0 && (
        <div className="relative pt-4 pb-10 border-b border-border mb-10 overflow-x-auto">
          <div className="relative h-40 min-w-[480px]">
            {/* Baseline */}
            <div className="absolute left-0 right-0 bottom-0 h-px bg-border" />

            {/* Progression line */}
            <svg className="absolute inset-0 w-full h-full overflow-visible" preserveAspectRatio="none">
              <motion.polyline
                initial={{ pathLength: 0, opacity: 0 }}
                whileInView={{ pathLength: 1, opacity: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 1.1, ease: [0.16, 1, 0.3, 1] }}
                fill="none"
                stroke="var(--brand)"
                strokeWidth="2"
                points={points
                  .map((p, i) => {
                    const x = (i / Math.max(1, points.length - 1 + (potential !== currentScan.safetyScore ? 1 : 0))) * 100;
                    const y = 100 - ((p.score - min) / range) * 100;
                    return `${x}%,${y}%`;
                  })
                  .join(" ")}
              />
              {potential !== currentScan.safetyScore && (
                <motion.line
                  initial={{ pathLength: 0, opacity: 0 }}
                  whileInView={{ pathLength: 1, opacity: 1 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.8, delay: 0.6, ease: [0.16, 1, 0.3, 1] }}
                  x1={`${(points.length > 1 ? (points.length - 1) / points.length : 0) * 100}%`}
                  y1={`${100 - ((currentScan.safetyScore - min) / range) * 100}%`}
                  x2="100%"
                  y2={`${100 - ((potential - min) / range) * 100}%`}
                  stroke="var(--foreground)"
                  strokeOpacity={0.35}
                  strokeWidth="2"
                  strokeDasharray="4 4"
                />
              )}
            </svg>

            {/* Points */}
            {points.map((p, i) => {
              const x = (i / Math.max(1, points.length - 1 + (potential !== currentScan.safetyScore ? 1 : 0))) * 100;
              const y = 100 - ((p.score - min) / range) * 100;
              return (
                <Link
                  key={p.id}
                  to={`/properties/${homeId}/rooms/${roomId}/assessments/${p.id}`}
                  className="absolute -translate-x-1/2 -translate-y-1/2 group"
                  style={{ left: `${x}%`, top: `${y}%` }}
                >
                  <motion.span
                    initial={{ scale: 0 }}
                    whileInView={{ scale: 1 }}
                    viewport={{ once: true }}
                    transition={{ delay: 0.2 + i * 0.1, type: "spring", stiffness: 400, damping: 20 }}
                    className={`block w-3 h-3 rounded-full ${dotColor(p.score)} ${p.isCurrent ? "ring-4 ring-brand/20" : ""} group-hover:scale-125 transition-transform`}
                  />
                  <div className="absolute top-5 left-1/2 -translate-x-1/2 whitespace-nowrap text-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <span className="tabular text-xs font-medium block">{p.score}</span>
                    <span className="text-[10px] text-muted-foreground">{new Date(p.date).toLocaleDateString(undefined, { month: "short", day: "numeric" })}</span>
                  </div>
                </Link>
              );
            })}

            {potential !== currentScan.safetyScore && (
              <div
                className="absolute -translate-x-1/2 -translate-y-1/2"
                style={{ left: "100%", top: `${100 - ((potential - min) / range) * 100}%` }}
              >
                <span className="block w-3 h-3 rounded-full border-2 border-dashed border-foreground/40 bg-background" />
                <div className="absolute top-5 right-0 whitespace-nowrap text-right">
                  <span className="tabular text-xs font-medium block">{potential}</span>
                  <span className="text-[10px] text-muted-foreground">Projected</span>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Report list */}
      <div className="border-t border-border">
        {[...history].reverse().map((s, i) => (
          <Link
            key={s.id}
            to={`/properties/${homeId}/rooms/${roomId}/assessments/${s.id}`}
            className={`flex items-center justify-between py-4 border-b border-border transition-colors ${
              s.id === currentScan.id ? "text-foreground" : "text-muted-foreground hover:text-foreground"
            }`}
          >
            <div className="flex items-center gap-4">
              <span className="tabular text-xs w-16 shrink-0">
                {new Date(s.createdAt).toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" })}
              </span>
              <span className="text-sm font-medium">
                {s.id === currentScan.id ? "This assessment" : "Assessment"}
              </span>
            </div>
            <span className={`tabular text-sm font-semibold ${scoreColor(s.safetyScore)}`}>{s.safetyScore}</span>
          </Link>
        ))}
        <div className="flex items-center justify-between py-4 text-muted-foreground/70">
          <span className="text-sm">If recommendations are completed</span>
          <span className="tabular text-sm font-semibold text-success">{potential}</span>
        </div>
      </div>
    </div>
  );
}
