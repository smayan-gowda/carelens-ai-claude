import { ShieldCheck, AlertTriangle } from 'lucide-react';
import { motion } from 'motion/react';

interface AiConfidencePanelProps {
  confidence?: number;
}

export function AiConfidencePanel({ confidence = 88 }: AiConfidencePanelProps) {
  const metrics = [
    { label: 'Image Quality', value: 92, note: 'Good' },
    { label: 'Room Coverage', value: 65, note: 'Partial' },
  ];

  return (
    <div className="border border-border bg-card p-6 h-full flex flex-col justify-between gap-6">
      <div className="flex items-start justify-between">
        <div>
          <span className="field-tag text-muted-foreground block mb-1.5">Model Confidence</span>
          <div className="flex items-center gap-2 text-muted-foreground">
            <ShieldCheck className="h-3.5 w-3.5 text-success" strokeWidth={1.75} />
            <span className="text-xs">CareLens Vision v2.4</span>
          </div>
        </div>
        <span className="tabular text-3xl font-semibold tracking-tight text-success">{confidence}%</span>
      </div>

      <div className="space-y-4">
        {metrics.map((m) => (
          <div key={m.label}>
            <div className="flex justify-between text-xs mb-1.5">
              <span className="text-muted-foreground">{m.label}</span>
              <span className={`tabular font-medium ${m.value < 80 ? 'text-warning' : 'text-foreground'}`}>{m.note} ({m.value}%)</span>
            </div>
            <div className="h-1 w-full bg-muted overflow-hidden">
              <motion.div
                className={`h-full ${m.value < 80 ? 'bg-warning' : 'bg-success'}`}
                initial={{ width: 0 }}
                whileInView={{ width: `${m.value}%` }}
                viewport={{ once: true }}
                transition={{ duration: 0.7, ease: [0.2, 0.8, 0.2, 1] }}
              />
            </div>
          </div>
        ))}
      </div>

      <div className="border-t border-dashed border-border pt-4 flex gap-2.5 text-xs text-muted-foreground leading-relaxed">
        <AlertTriangle className="h-3.5 w-3.5 shrink-0 mt-0.5 text-warning" strokeWidth={1.75} />
        <p>The model detected occlusion behind the main furniture. An additional photo from the opposite corner would complete the assessment.</p>
      </div>
    </div>
  );
}
