import { mergeProps } from "@base-ui/react/merge-props"
import { useRender } from "@base-ui/react/use-render"
import { cva, type VariantProps } from "class-variance-authority"

import { cn } from "@/lib/utils"

const badgeVariants = cva(
 "group/badge inline-flex h-5 w-fit shrink-0 items-center justify-center gap-1 overflow-hidden rounded-sm border border-transparent px-2 py-0.5 font-mono text-[10px] font-medium uppercase tracking-wider whitespace-nowrap transition-all focus-visible:border-ring focus-visible:ring-[3px] focus-visible:ring-ring/50 has-data-[icon=inline-end]:pr-1.5 has-data-[icon=inline-start]:pl-1.5 aria-invalid:border-destructive aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 [&>svg]:pointer-events-none [&>svg]:size-3!",
 {
 variants: {
 variant: {
 default: "bg-primary text-primary-foreground [a]:hover:bg-primary/80",
 secondary:
 "bg-secondary text-secondary-foreground [a]:hover:bg-secondary/80",
 brand: "bg-brand/10 text-brand [a]:hover:bg-brand/20",
 destructive:
 "bg-destructive/10 text-destructive focus-visible:ring-destructive/20 dark:bg-destructive/20 dark:focus-visible:ring-destructive/40 [a]:hover:bg-destructive/20",
 success:
 "bg-success/10 text-success focus-visible:ring-success/20 dark:bg-success/15 [a]:hover:bg-success/20",
 warning:
 "bg-warning/15 text-[color-mix(in_oklch,var(--warning),black_30%)] dark:text-warning focus-visible:ring-warning/20 [a]:hover:bg-warning/25",
 outline:
 "border-border text-foreground [a]:hover:bg-muted [a]:hover:text-muted-foreground",
 ghost:
 "hover:bg-muted hover:text-muted-foreground dark:hover:bg-muted/50",
 link: "text-primary underline-offset-4 hover:underline normal-case tracking-normal font-sans",
 },
 },
 defaultVariants: {
 variant: "default",
 },
 }
)

function Badge({
 className,
 variant = "default",
 render,
 ...props
}: useRender.ComponentProps<"span"> & VariantProps<typeof badgeVariants>) {
 return useRender({
 defaultTagName: "span",
 props: mergeProps<"span">(
 {
 className: cn(badgeVariants({ variant }), className),
 },
 props
 ),
 render,
 state: {
 slot: "badge",
 variant,
 },
 })
}

export { Badge, badgeVariants }
