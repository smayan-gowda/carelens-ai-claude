import * as React from "react"
import { Input as InputPrimitive } from "@base-ui/react/input"

import { cn } from "@/lib/utils"

function Input({ className, type, ...props }: React.ComponentProps<"input">) {
 return (
 <InputPrimitive
 type={type}
 data-slot="input"
 className={cn(
 "h-10 w-full min-w-0 rounded-md border border-border bg-background px-3.5 py-2 text-base transition-[border-color,box-shadow] duration-150 outline-none file:inline-flex file:h-6 file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-foreground placeholder:text-muted-foreground/60 hover:border-foreground/25 focus-visible:border-brand focus-visible:ring-2 focus-visible:ring-brand/15 disabled:pointer-events-none disabled:cursor-not-allowed disabled:opacity-50 aria-invalid:border-destructive aria-invalid:ring-2 aria-invalid:ring-destructive/20 md:text-sm dark:aria-invalid:border-destructive/50 dark:aria-invalid:ring-destructive/40",
 className
 )}
 {...props}
 />
 )
}

export { Input }
